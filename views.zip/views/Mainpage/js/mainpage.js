(function ($) {
   
       
    function fetchData() {

        $('#taulu').DataTable().destroy();
        $.ajax({
            url: "http://localhost:3002/fetchDevices",
            method: 'GET',
            "dataType": "json"
        }).done(function (data, textStatus, jqXHR) {

            editor = $('#taulu').DataTable({

                "data": data,
                "columns": [
                    { "data": "sarjanumero" },
                    { "data": "laite_id" },
                    { "data": "laite_nimi" },
                    { "data": "laite_merkki" },
                    { "data": "laite_malli" },
                    { "data": "omistaja" },
                    { "data": "sijainti" },
                    { "data": "kuvaus" },
                    { "defaultContent": "<button id=poistabutton>Poista</button>" },
                    { "defaultContent": "<button id=muokkaabutton>Muokkaa</button>" }
                     
                ],

                "language": {
                    "sEmptyTable": "Ei n�ytett�vi� tuloksia.",
                    "sInfo": "N�ytet��n rivit _START_ - _END_ (yhteens� _TOTAL_ )",
                    "sInfoEmpty": "N�ytet��n 0 - 0 (yhteens� 0)",
                    "sInfoFiltered": "(suodatettu _MAX_ tuloksen joukosta)",
                    "sInfoPostFix": "",
                    "sInfoThousands": ",",
                    "sLengthMenu": "N�yt� kerralla _MENU_ rivi�",
                    "sLoadingRecords": "Ladataan...",
                    "sProcessing": "Hetkinen...",
                    "sSearch": "Etsi:",
                    "sZeroRecords": "Tietoja ei l�ytynyt",
                    "oPaginate": {
                        "sFirst": "Ensimm�inen",
                        "sLast": "Viimeinen",
                        "sNext": "Seuraava",
                        "sPrevious": "Edellinen"
                    },
                    "oAria": {
                        "sSortAscending": ": A-Z",
                        "sSortDescending": ": Z-A"
                    },
                    "select": {
                        "rows": {
                            "_": "Valittuna %d rivi�",
                            "0": "Klikkaa rivi� valitaksesi sen",
                            "1": "Valittuna vain yksi rivi"
                        }
                    },
                    "buttons": {
                        "copy": "Kopioi",
                        "copySuccess": {
                            "1": "Yksi rivi kopioitu leikep�yd�lle",
                            "_": "%d rivi� kopioitu leikep�yd�lle"
                        },
                        "copyTitle": "Kopioi leikep�yd�lle",
                        "copyKeys": "Paina <i>ctrl</i> tai <i>\u2318</i> + <i>C</i> kopioidaksesi taulukon arvot<br> leikep�yd�lle. <br><br>Peruuttaaksesi klikkaa t�h�n tai Esc."
                    },
                }
            });

        }).fail(function (jqXHR, textStatus, errorThrown) {
            console.log("Kutsu ep�onnistui");

        }).always(function (jqXHR, textStatus, errorThrown) {
            console.log("meow");
        });
    }

    $('#lisaa').click(function () {
        var html = '<tr>';

        html += '<td contenteditable id="data1"></td>';
        html += '<td contenteditable id="data2"></td>';
        html += '<td contenteditable id="data3"></td>';
        html += '<td contenteditable id="data4"></td>';
        html += '<td contenteditable id="data5"></td>';
        html += '<td contenteditable id="data6"></td>';
        html += '<td contenteditable id="data7"></td>';
        html += '<td contenteditable id="data8"></td>';
        html += '<td><button type="button" name="insert" id="insert" >Lis��</button></td>';


        html += '</tr>';
        $('#taulu').prepend(html);
    });

    $(document).on('click', '#insert', function () {
        var Sarjanumero = $('#data1').text();
        var LaiteID = $('#data2').text();
        var Nimi = $('#data3').text();
        var Merkki = $('#data4').text();
        var Malli = $('#data5').text();
        var Omistaja = $('#data6').text();
        var Sijainti = $('#data7').text();
        var Kuvaus = $('#data8').text();

        $.ajax({
            url: "http://localhost:3002/addDevice",
            method: 'POST',
            data: {
                sarjanumero: Sarjanumero,
                laite_id: LaiteID,
                laite_nimi: Nimi,
                laite_merkki: Merkki,
                laite_malli: Malli,
                omistaja: Omistaja,
                sijainti: Sijainti,
                kuvaus: Kuvaus
            }
        }).done(function (data, textStatus, jqXHR) {
            console.log("create user ok");
            alert("Tiedot lis�tty!!!");
        }).fail(function (jqXHR, textStatus, errorThrown) {
            console.log("createUser-Kutsu ep�onnistui");
        }).always(function (jqXHR, textStatus, errorThrown) {
            console.log("Kutsu always");
        });

        $('#taulu').DataTable().destroy();
        fetchData();
    });

    $('#taulu').on('click', '#poistabutton', function () {

        var avain = $(this).closest('tr').find('td:eq(0)').text();

        if (confirm("Poistetaanko varmasti?")) {
            $.ajax({
                url: "http://localhost:3002/deleteDevice",
                method: "POST",
                data: { avain },
                success: function (data) {
                    $('#alert_message').html('<div class="alert alert-success">' + data + '</div>');
                    $('#taulu').DataTable().destroy();
                    fetchData();
                }
            });
            setInterval(function () {
                $('#alert_message').html('');
            }, 5000);
        }

    });
    
    


   


})(jQuery);
