(function ($) {
function modUser(keksi) {
       

        var etunimi = $('#etunimi').val();
        var sukunimi = $('#sukunimi').val();
        var tunnus = keksi;
        var salasana = $('#salasana1').val();
        var puhnro = $('#puhnro').val();
        var osoite = $('#osoite').val();
      


        $.ajax(
            {
                url: "http://localhost:3002/updateuser",
                method: 'POST',  // Vaihtoehtoina get, post, delete, put (ainakin)         
                data: { fname: etunimi, lname: sukunimi, email: tunnus, password: salasana, phone: puhnro, address: osoite } // json-muodossa data, joka halutaan l�hett�� serverille (sama kuin laittaisi url:n per��n ?delay=1) 
            }).done(function (data, textStatus, jqXHR) {
                // Suoritetaan kun kutsu on valmis
                console.log("create user ok");
                alert("Tiedot paivitetty!");
                window.location = "http://localhost:3002/settings?email=" + keksi

            }).fail(function (jqXHR, textStatus, errorThrown) {
                // Suoriteaan, jos kutsu ep�onnistuu
                console.log("createUser-Kutsu ep�onnistui");

            }).always(function (jqXHR, textStatus, errorThrown) {
                // suoritetaan aina (riippumatta onnistuiko kutsu vai ei)
                // HUOM! 1. parametri sis�lt�� datan jos kutsu onnistui ja 3. parametri jqXHR-olion. Jos kutsu ep�onnistui, 1. parametri on jqXHR-olio ja 3. errorThrown
                console.log("Kutsu always");

            });

    }

}) (jQuery);


