     
    function fetchData() {

        $('#taulu').DataTable().destroy();
        $.ajax({
            url: "http://localhost:3002/fetchDevices",
            method: 'GET',
            "dataType": "json"
        }).done(function (data, textStatus, jqXHR) {

            editor = $('#taulu').DataTable({

                "data": data,
                "columns": [
                    { "data": "laite_id" },          
                    { "data": "sarjanumero" },                  
                    { "data": "tyyppi_nimi" },
                    { "data": "laite_merkki" },
                    { "data": "laite_malli" },
                    { "data": "omistaja" },
                    { "data": "sijainti" },
                    { "data": "kuvaus" },
                    { "defaultContent": "<button id=poistabutton>Poista</button>" },
                    { "defaultContent": "<button id=muokkaabutton>Muokkaa</button>" }
                     
                ],

                "language": {
                    "sEmptyTable": "Ei n�ytett�vi� tuloksia.",
                    "sInfo": "N�ytet��n rivit _START_ - _END_ (yhteens� _TOTAL_ )",
                    "sInfoEmpty": "N�ytet��n 0 - 0 (yhteens� 0)",
                    "sInfoFiltered": "(suodatettu _MAX_ tuloksen joukosta)",
                    "sInfoPostFix": "",
                    "sInfoThousands": ",",
                    "sLengthMenu": "N�yt� kerralla _MENU_ rivi�",
                    "sLoadingRecords": "Ladataan...",
                    "sProcessing": "Hetkinen...",
                    "sSearch": "Etsi:",
                    "sZeroRecords": "Tietoja ei l�ytynyt",
                    "oPaginate": {
                        "sFirst": "Ensimm�inen",
                        "sLast": "Viimeinen",
                        "sNext": "Seuraava",
                        "sPrevious": "Edellinen"
                    },
                    "oAria": {
                        "sSortAscending": ": A-Z",
                        "sSortDescending": ": Z-A"
                    },
                    "select": {
                        "rows": {
                            "_": "Valittuna %d rivi�",
                            "0": "Klikkaa rivi� valitaksesi sen",
                            "1": "Valittuna vain yksi rivi"
                        }
                    },
                    "buttons": {
                        "copy": "Kopioi",
                        "copySuccess": {
                            "1": "Yksi rivi kopioitu leikep�yd�lle",
                            "_": "%d rivi� kopioitu leikep�yd�lle"
                        },
                        "copyTitle": "Kopioi leikep�yd�lle",
                        "copyKeys": "Paina <i>ctrl</i> tai <i>\u2318</i> + <i>C</i> kopioidaksesi taulukon arvot<br> leikep�yd�lle. <br><br>Peruuttaaksesi klikkaa t�h�n tai Esc."
                    },
                }
            });

        }).fail(function (jqXHR, textStatus, errorThrown) {
            console.log("Kutsu ep�onnistui");

        }).always(function (jqXHR, textStatus, errorThrown) {
            console.log("meow");
        });
}


    $('#lisaa').click(function () {
        var html = '<tr>';
        html += '<th id="data0"></th>';
        html += '<td contenteditable id="data1"></td>';
        html += '<td><select id="tyyppi"></select></td>';
        html += '<td contenteditable id="data4"></td>';
        html += '<td contenteditable id="data5"></td>';
        html += '<td contenteditable id="data6"></td>';
        html += '<td contenteditable id="data7"></td>';
        html += '<td contenteditable id="data8"></td>';
        html += '<td><button type="button" id="insert" >Lis��</button></td>';


        html += '</tr>';
        $('#taulu').prepend(html);


        $.ajax(
            {
                url: "http://localhost:3002/fetchTypes",
                method: 'GET', // Vaihtoehtoina get, post, delete, put (ainakin)
                dataType: 'JSON'
            }).done(function (data, textStatus, jqXHR) {
                // Suoritetaan kun kutsu on valmis
                console.log("get user ok");

                $.each(data, function (key, value) {
                    $('#tyyppi').append('<option value=' + value['tyyppi_id'] + '>' + value['tyyppi_nimi'] + '</option>');
                });

            

            }).fail(function (jqXHR, textStatus, errorThrown) {
                // Suoriteaan, jos kutsu ep�onnistuu
                console.log("createUser-Kutsu ep�onnistui");

            }).always(function (jqXHR, textStatus, errorThrown) {
                // suoritetaan aina (riippumatta onnistuiko kutsu vai ei)
                // HUOM! 1. parametri sis�lt�� datan jos kutsu onnistui ja 3. parametri jqXHR-olion. Jos kutsu ep�onnistui, 1. parametri on jqXHR-olio ja 3. errorThrown
                console.log("Kutsu always");

            });



    });

    $(document).on('click', '#insert', function () {
        var Sarjanumero = $('#data1').text();
        var tyyppi = $('#tyyppi option:selected').val();
        var Merkki = $('#data4').text();
        var Malli = $('#data5').text();
        var Omistaja = $('#data6').text();
        var Sijainti = $('#data7').text();
        var Kuvaus = $('#data8').text();

        $.ajax({
            url: "http://localhost:3002/addDevice",
            method: 'POST',
            data: {
                sarjanumero: Sarjanumero,
                tyyppi_id: tyyppi,
                laite_merkki: Merkki,
                laite_malli: Malli,
                omistaja: Omistaja,
                sijainti: Sijainti,
                kuvaus: Kuvaus
            }
        }).done(function (data, textStatus, jqXHR) {
            console.log("addDevice ok");
            alert("Tiedot lis�tty!!!");
            $('#taulu').DataTable().destroy();    
        }).fail(function (jqXHR, textStatus, errorThrown) {
            console.log("addDevice-Kutsu ep�onnistui");
        }).always(function (jqXHR, textStatus, errorThrown) {
            console.log("Kutsu always");
           
        });
        
        fetchData();
    });

    $('#taulu').on('click', '#poistabutton', function () {

        var avain = $(this).closest('tr').find('td:eq(0)').text();

        if (confirm("Poistetaanko varmasti?")) {
            $.ajax({
                url: "http://localhost:3002/deleteDevice",
                method: "POST",
                data: { avain },
                success: function (data) {
                    $('#alert_message').html('<div class="alert alert-success">' + data + '</div>');
                    $('#taulu').DataTable().destroy();
                    fetchData();
                }
            });
            setInterval(function () {
                $('#alert_message').html('');
            }, 5000);
        }

    });
    
    


   


