// npm install express
// npm install handlebars
// npm install consolidate

var express = require('express');
var cons = require('consolidate');
var app = express();
var path = require('path');
var bodyParser = require('body-parser');
var customerController = require('./Controller');


// Tulosta konsoliin mahdolliset enginet
//console.log(cons);

app.engine('html', cons.handlebars);
app.set('view engine', 'html');
app.set('views', path.join(__dirname, 'views'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static('./'));
//Login
//////////////////////////////////////////////////////////////////////////////
app.get('/', function(req, res) {
  res.render('login', {
    
  });
  });

app.get('/login', function(req, res) {
  res.render('login', {
    
  });
});

//Signup
//////////////////////////////////////////////////////////////////////////////

app.get('/Auth', function (req, res) {

    var email = req.param('auth');

         customerController.fetchLogin(email).then(function (data) {
                console.log(JSON.stringify(data));
                 return data;
        })
        .then((info) => {
            return info;
        })
        .catch(function (msg) {
            console.log("Virhettä pukkaa " + msg);
        })
        .then((info) => {
            //suoritetaan vaikka tulis virhe
            if (info === null) info = [{ kayttajanimi: null, salasana: null}];
            res.send(info);
        });
});

app.get('/signup', function(req, res) {
  res.render('signup', {
    
  });
});

app.route('/register')
    .post(customerController.createUser); 

//Mainpage
//////////////////////////////////////////////////////////////////////////////

app.get('/mainpage', function(req, res) {
  res.render('etusivu', {
    
  });
});

app.get('/homepage', function (req, res) {
    res.render('kotisivu', {

    });
});
//Settings
//////////////////////////////////////////////////////////////////////////////

app.get('/settings', function (req, res) {
    res.render('omattiedot', {

    });
});
app.get('/usersettings', function (req, res) {
    var email = req.param('email');
    customerController.fetchInfo(email).then(function(data){
        console.log(JSON.stringify(data));
        return data;    
    })
    .then((info) => {
        return info;
    })
    .catch(function(msg){
        console.log("Virhettä pukkaa " + msg);
    })
        .then((info) => {
         //suoritetaan vaikka tulis virhe
            if (info === null) info = [{ kayttajatunnus: 'null', etunimi: 'null', sukunimi: 'null', puhnro: 'null', osoite: 'null'}];
        res.send(info);        
        });

});

app.route('/updateUser')
    .post(customerController.updateUser); 

app.get('/Laitehallinta', function (req, res) {

    res.render('Laitehallinta', {

    });
});

//Devices
//////////////////////////////////////////////////////////////////////////////

app.get('/LoadEditDevice', function (req, res) {
    res.render('laitteenmuokkaus', {

    });
});

app.get('/fetchDevices', function (req, res) {

    customerController.fetchDevices().then(function (data) {
        console.log(JSON.stringify(data));
        return data;
    })
        .then((info) => {
            return info;
        })
        .catch(function (msg) {
            console.log("Virhettä pukkaa " + msg);
        })
        .then((info) => {
            //suoritetaan vaikka tulis virhe
            if (info === null) info = [{ sarjanumero: 'null', laite_nimi: 'null', laite_merkki: 'null', laite_malli: 'null', omistaja: 'null', sijainti: 'null', kuvaus: 'null' }];
            res.send(info);
        });
});

app.get('/EditDevice', function (req, res) {
    var laiteid = req.param("laiteid");
    customerController.fetchDevice(laiteid).then(function (data) {
        console.log(JSON.stringify(data));
        return data;
    })
        .then((info) => {
            return info;
        })
        .catch(function (msg) {
            console.log("Virhettä pukkaa " + msg);
        })
        .then((info) => {
            //suoritetaan vaikka tulis virhe
            if (info === null) info = [{ /* tänne, mitä halutaan palauttaa jos palautus on null */ }];
            res.send(info);
        });
});

app.route('/addType')
    .post(customerController.addType);

app.route('/addDevice')
    .post(customerController.addDevice);

app.route('/deleteDevice')
    .post(customerController.deleteDevice);

app.route('/updateDevice')
    .post(customerController.updateDevice);

//Orders
//////////////////////////////////////////////////////////////////////////////
app.get('/fetchStatus', function (req, res) {

    customerController.fetchStatus().then(function (data) {
        console.log(JSON.stringify(data));
        return data;
    })
        .then((info) => {
            return info;
        })
        .catch(function (msg) {
            console.log("Virhettä pukkaa " + msg);
        })
        .then((info) => {
            //suoritetaan vaikka tulis virhe
            if (info === null) info = [{ tila: "ei löytynyt" }];
            res.send(info);
        });
});

app.get('/fetchTypes', function (req, res) {
    
    customerController.fetchTypes().then(function (data) {
        console.log(JSON.stringify(data));
        return data;
    })
        .then((info) => {
            return info;
        })
        .catch(function (msg) {
            console.log("Virhettä pukkaa " + msg);
        })
        .then((info) => {
            //suoritetaan vaikka tulis virhe
            if (info === null) info = [{laite_nimi: "ei löytynyt"}];
            res.send(info);
        });
});

app.get('/fetchMyOrders', function (req, res) {
    var email = req.param('email');
    customerController.fetchMyOrders(email).then(function (data) {
        console.log(JSON.stringify(data));
        return data;
    })
        .then((info) => {
            return info;
        })
        .catch(function (msg) {
            console.log("Virhettä pukkaa " + msg);
        })
        .then((info) => {
            //suoritetaan vaikka tulis virhe
            if (info === null) info = [{varaus_id: "Ei löytynyt varauksia", sarjanumero: "null", laite_nimi: "null", laite_merkki: "null", laite_malli: "null", tila: "null", varauspvm: "null", lainauspvm: "null", palautuspvm: "null"}];
            res.send(info);
        });
});

app.get('/orderControl', function (req, res) {
    res.render('varaushallinta', {

    });
});


app.get('/fetchOrder', function (req, res) {
    var varaus_id = req.param('varaus_id')
    customerController.fetchOrder(varaus_id).then(function (data) {
        console.log(JSON.stringify(data));
        return data;
    })
        .then((info) => {
            return info;
        })
        .catch(function (msg) {
            console.log("Virhettä pukkaa " + msg);
        })
        .then((info) => {
            //suoritetaan vaikka tulis virhe
            if (info === null) info = [{ varaus_id: "Ei löytynyt varauksia", sarjanumero: "null", laite_nimi: "null", laite_merkki: "null", laite_malli: "null", tila: "null", varauspvm: "null", lainauspvm: "null", palautuspvm: "null" }];
            res.send(info);
        });
});

app.get('/fetchAllOrders', function (req, res) {
    
    customerController.fetchAllOrders().then(function (data) {
        console.log(JSON.stringify(data));
        return data;
    })
        .then((info) => {
            return info;
        })
        .catch(function (msg) {
            console.log("Virhettä pukkaa " + msg);
        })
        .then((info) => {
            //suoritetaan vaikka tulis virhe
            if (info === null) info = [{ varaus_id: "Ei löytynyt varauksia", sarjanumero: "null", laite_nimi: "null", laite_merkki: "null", laite_malli: "null", tila: "null", varauspvm: "null", lainauspvm: "null", palautuspvm: "null" }];
            res.send(info);
        });
});

app.get('/fetchDevicesForOrder', function (req, res) {

    var alku = req.param('alkupvm');
    var loppu = req.param("loppupvm");
    console.log(alku, loppu);

         customerController.fetchDevicesForOrder(alku, loppu).then(function (data) {
            console.log("LAITTEET VARAUSTA VARTEN: " + JSON.stringify(data));
            return data;
        })
        .then((info) => {
            return info;
            
        })
        .catch(function (msg) {
            console.log("Virhettä pukkaa " + msg);
        })
        .then((info) => {
        //suoritetaan vaikka tulis virhe
            if (info === null) info = [{laite_id: "null"}];
            res.send(info);
        });
});

app.get('/fetchOrdersForCalendar', function (req, res) {

    var id = req.param('laite_id');
    console.log(id);

        customerController.fetchOrdersForCalendar(id).then(function (data) {
            console.log(JSON.stringify(data));
            return data;
        })
        .then((info) => {
            return info;
        })
        .catch(function (msg) {
            console.log("Virhettä pukkaa " + msg);
        })
        .then((info) => {
            //suoritetaan vaikka tulis virhe
            if (info === null) info = [{ varaus_id: "Ei löytynyt varauksia", sarjanumero: "null", laite_nimi: "null", laite_merkki: "null", laite_malli: "null", status: "null", varauspvm: "null", lainauspvm: "null", palautuspvm: "null" }];
            res.send(info);
        });
});

app.get('/order', function (req, res) {
    res.render('kalenteri', {

    });
});

app.route('/updateOrder')
    .post(customerController.updateOrder);

app.route('/addOrder')
    .post(customerController.addOrder);

app.route('/deleteOrder')
    .post(customerController.deleteOrder);

//////////////////////////////////////////////////////////////////////////////

app.listen(3002);
console.log('Express server listening on port 3002');

