
(function ($) {
    "use strict";

    
    /*==================================================================
    [ Validate ]*/
    var input = $('.validate-input .input100');
    var email;
    var alert_pass = $('#pass');
    var alert_mail = $('#email');
    var password; 
    var check = true;
	var info;
    $('.login100-form-btn').on('click',function(){

        email = $('#email').val();
        password = $('#pass').val();

        for(var i=0; i<input.length; i++) {
            if(validate(input[i]) == false){
                showValidate(input[i]);
                check=false;
				
            }			
        }


        if (check === true) {
           //Luo Jquery session ja laita data sinne
           //Huomioi, ett� cookie pit�� my�s sulkea logoutissa ???
            LoginAuth();
           
        }

        return check;


    });

    function LoginAuth() {

        
        $.ajax(
            {
                url: "http://localhost:3002/Auth?auth=" + email,
                method: 'GET', // Vaihtoehtoina get, post, delete, put (ainakin)
                "dataType": "json"
               
                

            }).done(function (data, textStatus, jqXHR) {
                // Suoritetaan kun kutsu on valmis
                console.log("OK", data);
                // info = JSON.parse(data);
                

                if (typeof data[0] != 'undefined') {

                    var kayttaja = data[0]['kayttajanimi'];
                    var salasana = data[0]['salasana'];
                    var status = data[0]['tyyppi'];
                    var kayttaja_id = data[0]['kayttaja_id']
                    if (kayttaja === email && salasana === password) {

                        $.cookie('user', kayttaja, { expires: 1 });
                        $.cookie('status', status, { expires: 1 });
                        $.cookie('user_id', kayttaja_id, { expires: 1 })
                        //var currentusr = $.cookie('username');
                        window.location = "http://localhost:3002/mainpage";

                    }
                    if (kayttaja === email && salasana !== password) {
                        showValidate(input);
                    }
                    
                }
                else {
                    showValidate(input);
                }

            }).fail(function (jqXHR, textStatus, errorThrown) {
                // Suoriteaan, jos kutsu ep�onnistuu
                console.log("Kutsu ep�onnistui");

            }).always(function (jqXHR, textStatus, errorThrown) {
                // suoritetaan aina (riippumatta onnistuiko kutsu vai ei)
                // HUOM! 1. parametri sis�lt�� datan jos kutsu onnistui ja 3. parametri jqXHR-olion. Jos kutsu ep�onnistui, 1. parametri on jqXHR-olio ja 3. errorThrown
                console.log("Kutsu always");
              
            });

            

           
    }



    $('.validate-form .input100').each(function(){
        $(this).focus(function(){
           hideValidate(this);
        });
    });

    function validate (input) {
        if($(input).attr('type') == 'email' || $(input).attr('name') == 'email') {
            if($(input).val().trim().match(/^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)$/) == null) {
                return false;
            }
        }
        else {
            if($(input).val().trim() == ''){
                return false;
            }
        }
    }

    function showValidate(input) {
        var thisAlert = $(input).parent();

        $(thisAlert).addClass('alert-validate');
    }

    function hideValidate(input) {
        var thisAlert = $(input).parent();

        $(thisAlert).removeClass('alert-validate');
		
    }
    
    
})(jQuery);
