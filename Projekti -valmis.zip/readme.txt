npm install handlebars
npm install consolidate