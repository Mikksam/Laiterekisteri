'use strict';

// Asenna ensin mysql driver 
// npm install mysql --save

var mysql = require('mysql');

var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',  // HUOM! Älä käytä root:n tunnusta tuotantokoneella!!!!
  password : '',
  database : 'Laiterekisteri'
});

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

module.exports =
    {
     //Devices
    //////////////////////////////////////////////////////////////////////////////
        fetchDevices: function () {
            return new Promise((resolve, reject) => {
                connection.query('SELECT l.laite_id, l.sarjanumero, t.tyyppi_nimi, l.laite_merkki, l.laite_malli, l.omistaja, l.sijainti, l.kuvaus FROM laite AS l INNER JOIN laitetyyppi AS t ON l.tyyppi_id = t.tyyppi_id', function (error, results, fields) {
                    if (error) {
                        console.log("Virhe haettaessa dataa laite-taulusta, syy: " + error);
                        reject("Virhe haettaessa dataa laite-taulusta, syy: " + error);
                    }
                    else {
                        console.log("Data (rev) = " + JSON.stringify(results));
                        resolve(results);
                    }
                });
            });
        },

        fetchDevice: function (avain) {
            return new Promise((resolve, reject) => {
                connection.query('SELECT l.laite_id, l.sarjanumero, l.tyyppi_id, t.tyyppi_nimi, l.laite_merkki, l.laite_malli, l.omistaja, l.sijainti, l.kuvaus FROM laite AS l INNER JOIN laitetyyppi AS t ON l.tyyppi_id = t.tyyppi_id WHERE laite_id = ?', [avain], function (error, results, fields) {
                    if (error) {
                        console.log("Virhe haettaessa dataa laite-taulusta, syy: " + error);
                        reject("Virhe haettaessa dataa laite-taulusta, syy: " + error);
                    }
                    else {
                        console.log("Data (rev) = " + JSON.stringify(results));
                        resolve(results);
                    }
                });
            });
        },

        addDevice: function (req, res) {
            let c = req.body;
            console.log("body (CREATE): " + JSON.stringify(c));
            connection.query('INSERT INTO laite (sarjanumero, tyyppi_id, laite_merkki, laite_malli, omistaja, sijainti, kuvaus) VALUES (?, ?, ?, ?, ?, ?, ?)', [c.sarjanumero, c.tyyppi_id, c.laite_merkki, c.laite_malli, c.omistaja, c.sijainti, c.kuvaus],
                function (error, results, fields) {
                    if (error) {
                        console.log("Virhe lisättäessä dataa laite-tauluun, syy: " + error);
                        res.send(error);
                    }
                    else {
                        console.log("Data = " + JSON.stringify(results));
                        res.statusCode = 201;
                        c.Avain = results.insertId;
                        res.send(c);
                    }
                });
        },

        addType: function (req, res) {
            let c = req.body;
            console.log("body (ADD TYPE): " + JSON.stringify(c));
            connection.query('INSERT INTO laitetyyppi (tyyppi_nimi) VALUES (?)', [c.tyyppi_nimi],
                function (error, results, fields) {
                    if (error) {
                        console.log("Virhe lisättäessä dataa laite-tauluun, syy: " + error);
                        res.send(error);
                    }
                    else {
                        console.log("Data = " + JSON.stringify(results));
                        res.statusCode = 201;
                        c.Avain = results.insertId;
                        res.send(c);
                    }
                });
        },

        fetchDevicesForDelete: function (id) {
            return new Promise((resolve, reject) => {

                connection.query('SELECT * FROM varaus_view WHERE laite_id = ?', [id], function (error, results, fields) {
                    if (error) {
                        console.log("Virhe haettaessa dataa varaus-taulusta, syy: " + error);
                        reject("Virhe haettaessa dataa varaus-taulusta, syy: " + error);
                    }
                    else {
                        console.log("Data (rev) = " + JSON.stringify(results));
                        resolve(results);
                    }
                });
            });
        },

        deleteDevice: function (req, res) {
            let c = req.body;
            console.log("body (DELETE): " + JSON.stringify(c));
            connection.query('DELETE FROM laite WHERE laite_id = ?', [c.avain],
                function (error, results, fields) {
                    if (error) {
                        console.log("Virhe poistettaessa dataa laite-taulusta, syy: " + error);
                        res.send(error);
                    }
                    else {
                        console.log("Data = " + JSON.stringify(results));
                        res.statusCode = 201;
                        c.Avain = results.insertId;
                        res.send(c);
                    }
                });
        },


        updateDevice: function (req, res) {
            let c = req.body;
            console.log("body (UPDATE): " + JSON.stringify(c));
            connection.query('UPDATE laite SET sarjanumero = ?, tyyppi_id = ?, laite_merkki = ?, laite_malli = ?, omistaja = ?, sijainti = ?, kuvaus = ? WHERE laite_id = ?', [c.sarjanumero, c.tyyppi_id, c.laite_merkki, c.laite_malli, c.omistaja, c.sijainti, c.kuvaus, c.laiteid],
                function (error, results, fields) {
                    if (error) {
                        console.log("Virhe muutettaessa dataa laite-tauluun, syy: " + error);
                        res.send(error);
                    }
                    else {
                        console.log("Data = " + JSON.stringify(results));
                        res.statusCode = 201;
                        c.Avain = results.insertId;
                        res.send(c);
                    }
                });
        },


     //User
    //////////////////////////////////////////////////////////////////////////////

        fetchInfo: function (email) {
            return new Promise((resolve, reject) => {

                connection.query('SELECT * FROM kayttaja WHERE kayttajanimi = ?', [email], function (error, results, fields) {
                    if (error) {
                        console.log("Virhe haettaessa dataa Asiakas-taulusta, syy: " + error);
                        reject("Virhe haettaessa dataa Asiakas-taulusta, syy: " + error);
                    }
                    else {
                        console.log("Data (rev) = " + JSON.stringify(results));
                        resolve(results);
                    }
                });
            });
        },
        // Sama kuin edellinen! muista tehdä muutoksen siten, että voi ottaa tämän pois!!!
        fetchLogin: function (email) {
            return new Promise((resolve, reject) => {

                connection.query('SELECT * FROM kayttaja WHERE kayttajanimi =? ', [email], function (error, results, fields) {
                    if (error) {
                        console.log("Virhe haettaessa dataa kayttaja-taulusta, syy: " + error);
                        reject("Virhe haettaessa dataa kayttaja-taulusta, syy: " + error);
                    }
                    else {
                        console.log("Data (rev) = " + JSON.stringify(results));
                        resolve(results);
                    }
                });
            });
        },

        updateUser: function (req, res) {

            var c = req.body;
            console.log("body (UPDATE): " + JSON.stringify(req.body));


            connection.query("UPDATE kayttaja SET salasana = ?, etunimi = ?, sukunimi = ?, puhnro = ?, osoite = ? WHERE kayttajanimi = ?", [c.password, c.fname, c.lname, c.phone, c.address, c.email],
                function (error, results, fields) {
                    if (error) {
                        console.log("Virhe muuttaessa dataa kayttaja-tauluun, syy: " + error);
                        res.send(error);
                    }
                    else {
                        console.log("Data = " + JSON.stringify(results));
                        res.statusCode = 201;
                        c.Avain = results.insertId;
                        res.send(c);
                    }

                });

        },

        createUser: function (req, res) {
            let c = req.body;
            console.log("body (CREATEUSER): " + JSON.stringify(c));

            connection.query('INSERT INTO kayttaja (kayttajanimi, salasana, tyyppi, tyyppi_selite, Luontipvm, etunimi, sukunimi ) VALUES (?, ?, 2, "Customer", CURDATE(), ? , ?)', [c.email, c.password, c.fname, c.lname],
                function (error, results, fields) {
                    if (error) {
                        console.log("Virhe lisättäessä dataa kayttaja-tauluun, syy: " + error);
                        res.send(error);
                    }
                    else {
                        console.log("Data = " + JSON.stringify(results));
                        res.statusCode = 201;
                        c.Avain = results.insertId;
                        res.send(c);
                    }
                });
        },


     //Orders
    //////////////////////////////////////////////////////////////////////////////

        fetchStatus: function () {

            return new Promise((resolve, reject) => {
                connection.query('SELECT * FROM varauksentila', function (error, results, fields) {
                    if (error) {
                        console.log("Virhe haettaessa dataa varaus-taulusta, syy: " + error);
                        reject("Virhe haettaessa dataa varaus-taulusta, syy: " + error);
                    }
                    else {
                        console.log("Data (rev) = " + JSON.stringify(results));
                        resolve(results);
                    }
                });
            });
        },


        fetchMyOrders: function (email) {

                return new Promise((resolve, reject) => {

                    connection.query('SELECT v.varaus_id, l.sarjanumero, t.tyyppi_nimi, l.laite_merkki, l.laite_malli, s.tila, v.varauspvm, v.lainauspvm, v.palautuspvm FROM varaus AS v INNER JOIN laite AS l ON v.laite_id = l.laite_id INNER JOIN laitetyyppi AS t ON l.tyyppi_id = t.tyyppi_id INNER JOIN kayttaja AS k ON v.kayttaja_id = k.kayttaja_id INNER JOIN varauksentila AS s ON v.status = s.status WHERE k.kayttajanimi = ?', [email], function (error, results, fields) {
                        if (error) {
                            console.log("Virhe haettaessa dataa varaus-taulusta, syy: " + error);
                            reject("Virhe haettaessa dataa varaus-taulusta, syy: " + error);
                        }
                        else {
                            console.log("Data (rev) = " + JSON.stringify(results));
                            resolve(results);
                        }
                    });
                });
        },

        fetchOrder: function (varaus_id) {

            return new Promise((resolve, reject) => {

                connection.query('SELECT v.varaus_id,l.laite_id, l.sarjanumero, t.tyyppi_nimi, l.laite_merkki, l.laite_malli, s.tila, v.status, v.varauspvm, v.lainauspvm, v.palautuspvm FROM varaus AS v INNER JOIN laite AS l ON v.laite_id = l.laite_id INNER JOIN laitetyyppi AS t ON l.tyyppi_id = t.tyyppi_id INNER JOIN kayttaja AS k ON v.kayttaja_id = k.kayttaja_id INNER JOIN varauksentila AS s ON v.status = s.status WHERE v.varaus_id = ?', [varaus_id], function (error, results, fields) {
                    if (error) {
                        console.log("Virhe haettaessa dataa varaus-taulusta, syy: " + error);
                        reject("Virhe haettaessa dataa varaus-taulusta, syy: " + error);
                    }
                    else {
                        console.log("Data (rev) = " + JSON.stringify(results));
                        resolve(results);
                    }
                });
            });
        },

        fetchAllOrders: function () {

            return new Promise((resolve, reject) => {

                connection.query('SELECT v.varaus_id, k.kayttajanimi, k.etunimi, k.sukunimi, l.sarjanumero, t.tyyppi_nimi, l.laite_merkki, l.laite_malli, s.tila, v.varauspvm, v.lainauspvm, v.palautuspvm FROM varaus AS v INNER JOIN laite AS l ON v.laite_id = l.laite_id INNER JOIN laitetyyppi AS t ON l.tyyppi_id = t.tyyppi_id INNER JOIN kayttaja AS k ON v.kayttaja_id = k.kayttaja_id INNER JOIN varauksentila AS s ON v.status = s.status ', function (error, results, fields) {
                    if (error) {
                        console.log("Virhe haettaessa dataa varaus-taulusta, syy: " + error);
                        reject("Virhe haettaessa dataa varaus-taulusta, syy: " + error);
                    }
                    else {
                        console.log("Data (rev) = " + JSON.stringify(results));
                        resolve(results);
                    }
                });
            });
        },

        fetchTypes: function () {

            return new Promise((resolve, reject) => {
                connection.query('SELECT * FROM laitetyyppi', function (error, results, fields) {
                    if (error) {
                        console.log("Virhe haettaessa dataa varaus-taulusta, syy: " + error);
                        reject("Virhe haettaessa dataa varaus-taulusta, syy: " + error);
                    }
                    else {
                        console.log("Data (rev) = " + JSON.stringify(results));
                        resolve(results);
                    }
                });
            });
        },
   // SELECT l.laite_id, l.sarjanumero, t.tyyppi_nimi, l.laite_merkki, l.laite_malli, l.omistaja, l.sijainti, l.kuvaus FROM laite AS l INNER JOIN laitetyyppi AS t ON l.tyyppi_id = t.tyyppi_id WHERE l.laite_id NOT IN(SELECT laite_id FROM varaus) OR l.laite_id IN (select laite_id from varaukset GROUP BY laite_id HAVING SUM(CASE WHEN lainauspvm NOT BETWEEN ? AND ? THEN 0 ELSE 1 END) = 0 AND (CASE WHEN palautuspvm NOT BETWEEN ? AND ? THEN 0 ELSE 1 END) = 0 )

        
        //fetchDevicesForOrder: function (alku, loppu) {
        //    return new Promise((resolve, reject) => {

        //        connection.query('SELECT l.laite_id, l.sarjanumero, t.tyyppi_nimi, l.laite_merkki, l.laite_malli, l.omistaja, l.sijainti, l.kuvaus FROM laite AS l LEFT OUTER JOIN varaus AS v ON l.laite_id = v.laite_id INNER JOIN laitetyyppi AS t ON l.tyyppi_id = t.tyyppi_id WHERE (v.lainauspvm NOT BETWEEN ? AND ?) AND (v.palautuspvm NOT BETWEEN ? AND ?) OR l.laite_id NOT IN (SELECT laite_id FROM varaus) GROUP BY l.laite_id', [alku , loppu, alku, loppu], function (error, results, fields) {
        //            if (error) {
        //                console.log("Virhe haettaessa dataa varaus-taulusta, syy: " + error);
        //                reject("Virhe haettaessa dataa varaus-taulusta, syy: " + error);
        //            }
        //            else {
        //                console.log("Data (rev) = " + JSON.stringify(results));
        //                resolve(results);
        //            }
        //        });
        //    });
        //},

        // Kiva ominaisuus, mutta ei toiminut käytännössä
        fetchDevicesForOrder: function (alku, loppu) {
            return new Promise((resolve, reject) => {

                connection.query('SELECT * FROM varaus_view WHERE laite_id NOT IN (SELECT laite_id FROM varaus_view WHERE (lainauspvm BETWEEN ? AND ?) OR (palautuspvm BETWEEN ? AND ?) GROUP BY laite_id) OR laite_id IS NULL OR status = 6 GROUP BY sarjanumero', [alku, loppu, alku, loppu], function (error, results, fields) {
                    if (error) {
                        console.log("Virhe haettaessa dataa varaus-taulusta, syy: " + error);
                        reject("Virhe haettaessa dataa varaus-taulusta, syy: " + error);
                    }
                    else {
                        console.log("Data (rev) = " + JSON.stringify(results));
                        resolve(results);
                    }
                });
            });
        },

        checkOrder: function (id, alku, loppu) {
            return new Promise((resolve, reject) => {

                connection.query('SELECT * FROM varaus_view WHERE laite_id = ? AND sarjanumero NOT IN (SELECT sarjanumero FROM varaus_view WHERE (lainauspvm BETWEEN ? AND ?) OR (palautuspvm BETWEEN ? AND ?) GROUP BY laite_id) OR laite_id IS NULL OR status = 6 GROUP BY sarjanumero', [id, alku, loppu, alku, loppu], function (error, results, fields) {
                    if (error) {
                        console.log("Virhe haettaessa dataa varaus-taulusta, syy: " + error);
                        reject("Virhe haettaessa dataa varaus-taulusta, syy: " + error);
                    }
                    else {
                        console.log("Data (rev) = " + JSON.stringify(results));
                        resolve(results);
                    }
                });
            });
        },

        fetchOrdersForCalendar: function (id) {
            return new Promise((resolve, reject) => {

                connection.query('SELECT v.varaus_id, l.sarjanumero, v.lainauspvm, v.palautuspvm FROM varaus AS v INNER JOIN laite AS l ON v.laite_id = l.laite_id WHERE v.laite_id = ?', [id], function (error, results, fields) {
                    if (error) {
                        console.log("Virhe haettaessa dataa varaus-taulusta, syy: " + error);
                        reject("Virhe haettaessa dataa varaus-taulusta, syy: " + error);
                    }
                    else {
                        console.log("Data (rev) = " + JSON.stringify(results));
                        resolve(results);
                    }
                });
           });
        },


        addOrder: function (req, res) {
            let c = req.body;
            console.log("body (CREATE): " + JSON.stringify(c));
            connection.query('INSERT INTO varaus (kayttaja_id, laite_id, status, varauspvm, lainauspvm, palautuspvm) VALUES (?, ?, ?, NOW(), ?, ?)', [c.kayttaja_id, c.laite_id, c.status, c.lainauspvm, c.palautuspvm],
                function (error, results, fields) {
                    if (error) {
                        console.log("Virhe lisättäessä dataa varaus-tauluun, syy: " + error);
                        res.send(error);
                    }
                    else {
                        console.log("Data = " + JSON.stringify(results));
                        res.statusCode = 201;
                        c.Avain = results.insertId;
                        res.send(c);
                    }
                });
        },


        deleteOrder: function (req, res) {
            let c = req.body;
            console.log("body (DELETE): " + JSON.stringify(c));
            connection.query('DELETE FROM varaus WHERE varaus.varaus_id = ?', [c.varaus_id],
                function (error, results, fields) {
                    if (error) {
                        console.log("Virhe poistettaessa dataa varaus-taulusta, syy: " + error);
                        res.send(error);
                    }
                    else {
                        console.log("Data = " + JSON.stringify(results));
                        res.statusCode = 201;
                        c.Avain = results.insertId;
                        res.send(c);
                    }
                });
        },


        updateOrder: function (req, res) {
            let c = req.body;
            console.log("body (UPDATE): " + JSON.stringify(c));
            connection.query('UPDATE varaus SET status = ?, lainauspvm = ?, palautuspvm = ? WHERE varaus_id = ?', [c.status, c.lainauspvm, c.palautuspvm , c.varaus_id],
                function (error, results, fields) {
                    if (error) {
                        console.log("Virhe muutettaessa dataa varaus-tauluun, syy: " + error);
                        res.send(error);
                    }
                    else {
                        console.log("Data = " + JSON.stringify(results));
                        res.statusCode = 201;
                        c.Avain = results.insertId;
                        res.send(c);
                    }
                });
        }

    };

    



