
(function ($) {
    "use strict";

    
    /*==================================================================
    [ Validate ]*/
    var input = $('.validate-input .input100');
    var email;
    var password; 
    var check = true;
	var info;
    $('.login100-form-btn').on('click',function(){

        email = $('#email').val();
        password = $('#pass').val();

        for(var i=0; i<input.length; i++) {
            if(validate(input[i]) == false){
                showValidate(input[i]);
                check=false;
				
            }			
        }


        if (check === true) {
           //Luo Jquery session ja laita data sinne
           //Huomioi, ett� cookie pit�� my�s sulkea logoutissa ???
            LoginAuth();
           
        }

            //window.location = "http://localhost:3002/mainpage";
            //cookie(email);



        if (!!$.cookie('demo')) {
            // have cookie
            console.log("l��ty");
        } else {
            // no cookie
            console.log("eep� l��vy");
        }
		

        
        return check;


    });

    function LoginAuth() {

        
        $.ajax(
            {
                url: "http://localhost:3002/Auth?auth=" + email,
                method: 'GET', // Vaihtoehtoina get, post, delete, put (ainakin)
                "dataType": "json"
               
                

            }).done(function (data, textStatus, jqXHR) {
                // Suoritetaan kun kutsu on valmis
                console.log("OK", data);
                // info = JSON.parse(data);
                info = JSON.stringify(data);
                alert(info);
                
                console.log(data);

                if (info.kayttajanimi == email && info.salasana === password) {


                    $.cookie('demo', 'email', { expires: 1 });
                    var currentusr = $.cookie('username');
                    window.location = "http://localhost:3002/mainpage";

                }
                else {
                    check = false;

                }


            }).fail(function (jqXHR, textStatus, errorThrown) {
                // Suoriteaan, jos kutsu ep�onnistuu
                console.log("Kutsu ep�onnistui");

            }).always(function (jqXHR, textStatus, errorThrown) {
                // suoritetaan aina (riippumatta onnistuiko kutsu vai ei)
                // HUOM! 1. parametri sis�lt�� datan jos kutsu onnistui ja 3. parametri jqXHR-olion. Jos kutsu ep�onnistui, 1. parametri on jqXHR-olio ja 3. errorThrown
                console.log("Kutsu always");
              
            });

             alert(info.kayttaja_id + info.tyyppi + info.etunimi);

           
    }



    $('.validate-form .input100').each(function(){
        $(this).focus(function(){
           hideValidate(this);
        });
    });

    function validate (input) {
        if($(input).attr('type') == 'email' || $(input).attr('name') == 'email') {
            if($(input).val().trim().match(/^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)$/) == null) {
                return false;
            }
        }
        else {
            if($(input).val().trim() == ''){
                return false;
            }
        }
    }

    function showValidate(input) {
        var thisAlert = $(input).parent();

        $(thisAlert).addClass('alert-validate');
    }

    function hideValidate(input) {
        var thisAlert = $(input).parent();

        $(thisAlert).removeClass('alert-validate');
		
    }
    
    
})(jQuery);
