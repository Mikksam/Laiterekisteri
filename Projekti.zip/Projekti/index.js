// npm install express
// npm install handlebars
// npm install consolidate

var express = require('express');
var cons = require('consolidate');
var app = express();
var path = require('path');
var bodyParser = require('body-parser');
var customerController = require('./Controller');


// Tulosta konsoliin mahdolliset enginet
//console.log(cons);

app.engine('html', cons.handlebars);
app.set('view engine', 'html');
app.set('views', path.join(__dirname, 'views'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static('./'));

app.get('/', function(req, res) {
  res.render('login', {
    
  });
  });

app.get('/login', function(req, res) {
  res.render('login', {
    
  });
});

app.get('/Auth', function (req, res) {

    var email = req.param('auth');

         customerController.fetchLogin(email).then(function (data) {
                console.log(JSON.stringify(data));
                 return data;
        })
        .then((info) => {
            return info;
        })
        .catch(function (msg) {
            console.log("Virhettä pukkaa " + msg);
        })
        .then((info) => {
            //suoritetaan vaikka tulis virhe
            if (info == null) info = [{ kayttajatunnus: 'null', etunimi: 'null', sukunimi: 'null', puhnro: 'null', osoite: 'null' }];
            res.send(info);
        });
});

app.get('/signup', function(req, res) {
  res.render('signup', {
    
  });
});

app.get('/mainpage', function(req, res) {
  res.render('etusivu', {
    
  });
});

app.get('/homepage', function (req, res) {
    res.render('kotisivu', {

    });
});

app.get('/settings', function (req, res) {
    
    customerController.fetchInfo().then(function(data){
        console.log(JSON.stringify(data));
        return data;    
    })
    .then((info) => {
        return info;
    })
    .catch(function(msg){
        console.log("Virhettä pukkaa " + msg);
    })
        .then((info) => {
         //suoritetaan vaikka tulis virhe
            if (info == null) info = [{ kayttajatunnus: 'null', etunimi: 'null', sukunimi: 'null', puhnro: 'null', osoite: 'null'}];
        res.render('omattiedot', {            
            info: info           
        });        
    });

});

app.get('/customers', function(req, res) {

    customerController.fetchCustRevised().then(function(data){
        console.log("Cust = " + JSON.stringify(data));
        return data;    
    })
    .then((cust) => {
        return cust;
    })
    .catch(function(msg){
        console.log("Virhettä pukkaa " + msg);
    })
    .then((cust) => {
        // suoritetaan vaikka tulis virhe
        if ( cust == null ) cust = [{AVAIN:"", NIMI:"Ei löydy", OSOITE: "eipä mikkään", POSTINRO: "00000", POSTITMP: "Tyhyjä", ASTY_AVAIN: "0"}];
        res.render('customers', {
            customers:cust
        });        
    });

});
app.get('/customer', function(req, res) {
	var avain = req.param('avain');
    customerController.getCust(avain).then(function(data){
        console.log("Cust = " + JSON.stringify(data));
        return data;    
    })
    .then((cust) => {
        return cust;
    })
    .catch(function(msg){
        console.log("Virhettä pukkaa " + msg);
    })
    .then((cust) => {
        // suoritetaan vaikka tulis virhe
        if ( cust == null ) cust = [{AVAIN:"", NIMI:"Ei löydy", OSOITE: "eipä mikkään", POSTINRO: "00000", POSTITMP: "Tyhyjä", ASTY_AVAIN: "0"}];
        res.render('customer', {
            customer:cust
			
        });        
    });

});

app.route('/muuta') 
	.post(customerController.update);
  
  




app.listen(3002);
console.log('Express server listening on port 3002');

