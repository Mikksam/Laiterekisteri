'use strict'

// Asenna ensin mysql driver 
// npm install mysql --save

var mysql = require('mysql');

var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',  // HUOM! Älä käytä root:n tunnusta tuotantokoneella!!!!
  password : '',
  database : 'Laiterekisteri'
});

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

module.exports =
    {
    //Devices
    //////////////////////////////////////////////////////////////////////////////
        fetchDevices: function (email) {
            return new Promise((resolve, reject) => {
                connection.query('SELECT * FROM laite', function (error, results, fields) {
                    if (error) {
                        console.log("Virhe haettaessa dataa Käyttäjä-taulusta, syy: " + error);
                        reject("Virhe haettaessa dataa Käyttäjä-taulusta, syy: " + error);
                    }
                    else {
                        console.log("Data (rev) = " + JSON.stringify(results));
                        resolve(results);
                    }
                })
            })
        },
        addDevice: function (req, res) {
            let c = req.body;
            console.log("body (CREATE): " + JSON.stringify(c));
            connection.query('INSERT INTO laite (sarjanumero, laite_id, laite_nimi, laite_merkki, laite_malli, omistaja, sijainti, kuvaus) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', [c.sarjanumero, c.laite_id, c.laite_nimi, c.laite_merkki, c.laite_malli, c.omistaja, c.sijainti, c.kuvaus],
                function (error, results, fields) {
                    if (error) {
                        console.log("Virhe lisättäessä dataa Asiakas-tauluun, syy: " + error);
                        res.send(error);
                    }
                    else {
                        console.log("Data = " + JSON.stringify(results));
                        res.statusCode = 201;
                        c.Avain = results.insertId;
                        res.send(c);
                    }
                });
        },

        deleteDevice: function (req, res) {
            let c = req.body;
            console.log("body (CREATE): " + JSON.stringify(c));
            connection.query('DELETE FROM laite WHERE sarjanumero=?', [c.avain],
                function (error, results, fields) {
                    if (error) {
                        console.log("Virhe lisättäessä dataa Asiakas-tauluun, syy: " + error);
                        res.send(error);
                    }
                    else {
                        console.log("Data = " + JSON.stringify(results));
                        res.statusCode = 201;
                        c.Avain = results.insertId;
                        res.send(c);
                    }
                });
        },
          //User
    //////////////////////////////////////////////////////////////////////////////
        fetchInfo: function (email) {
            return new Promise((resolve, reject) => {

                connection.query('SELECT * FROM kayttaja WHERE kayttajanimi =? ', [email], function (error, results, fields) {
                    if (error) {
                        console.log("Virhe haettaessa dataa Asiakas-taulusta, syy: " + error);
                        reject("Virhe haettaessa dataa Asiakas-taulusta, syy: " + error);
                    }
                    else {
                        console.log("Data (rev) = " + JSON.stringify(results));
                        resolve(results);
                    }
                });
            });
        },

        fetchLogin: function (email) {
            return new Promise((resolve, reject) => {

                connection.query('SELECT * FROM kayttaja WHERE kayttajanimi =? ', [email], function (error, results, fields) {
                    if (error) {
                        console.log("Virhe haettaessa dataa Käyttäjä-taulusta, syy: " + error);
                        reject("Virhe haettaessa dataa Käyttäjä-taulusta, syy: " + error);
                    }
                    else {
                        console.log("Data (rev) = " + JSON.stringify(results));
                        resolve(results);
                    }
                });
            });
        },

        updateUser: function (req, res) {

            var c = req.body;
            console.log("body (UPDATE): " + JSON.stringify(req.body));


            connection.query("UPDATE kayttaja SET salasana = ?, etunimi = ?, sukunimi = ?, puhnro = ?, osoite = ? WHERE kayttajanimi = ?", [c.password, c.fname, c.lname, c.phone, c.address, c.email],
                function (error, results, fields) {
                    if (error) {
                        console.log("Virhe lisättäessä dataa Asiakas-tauluun, syy: " + error);
                        res.send(error);
                    }
                    else {
                        console.log("Data = " + JSON.stringify(results));
                        res.statusCode = 201;
                        c.Avain = results.insertId;
                        res.send(c);
                    }

                });

        },

        createUser: function (req, res) {
            let c = req.body;
            console.log("body (CREATEUSER): " + JSON.stringify(c));

            connection.query('INSERT INTO kayttaja (kayttajanimi, salasana, tyyppi, tyyppi_selite, Luontipvm, etunimi, sukunimi ) VALUES (?, ?, 2, "Customer", CURDATE(), ? , ?)', [c.email, c.password, c.fname, c.lname],
                function (error, results, fields) {
                    if (error) {
                        console.log("Virhe lisättäessä dataa Asiakas-tauluun, syy: " + error);
                        res.send(error);
                    }
                    else {
                        console.log("Data = " + JSON.stringify(results));
                        res.statusCode = 201;
                        c.Avain = results.insertId;
                        res.send(c);
                    }
                });
        }
    };
