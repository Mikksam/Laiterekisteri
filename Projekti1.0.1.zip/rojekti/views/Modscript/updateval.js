
(function ($) {
    "use strict";


    /*==================================================================
    [ Focus Contact2 ]*/
    //$('.input100').each(function () {
    //    $(this).on('blur', function () {
    //        if ($(this).val().trim() !== "") {
    //            $(this).addClass('has-val');
    //        }
    //        else {
    //            $(this).removeClass('has-val');
    //        }
    //    });
    //});
  
  
    /*==================================================================
    [ Validate ]*/
    var name = $('.validate-input input[name="name"]');
    var email = $('.validate-input input[name="email"]');
    var password1 = $('.validate-input input[name="password1"]');
    var password2 = $('.validate-input input[name="password2"]');


    $('#button').on('click',function(){
        var check = true;

        if($(name).val().trim() === ''){
            showValidate(name);
            check=false;
        }

        if ($(password1).val().trim() === '') {
            showValidate(password1);
            check = false;
        }

        if ($(password2).val().trim() === '') {
            showValidate(password2);
            check = false;
        }

        if ($(password1).val().trim() !== $(password2).val().trim()) {
            showValidate(password2);
            check = false;

        }
       
        if (check === true) {
            modUser();
        }

        return check;
    });


    $('.validate-form .input100').each(function(){
        $(this).focus(function(){
           hideValidate(this);
       });
    });

    function showValidate(input) {
        var thisAlert = $(input).parent();

        $(thisAlert).addClass('alert-validate');
    }

    function hideValidate(input) {
        var thisAlert = $(input).parent();

        $(thisAlert).removeClass('alert-validate');
    }
    
    

})(jQuery);