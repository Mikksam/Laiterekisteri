

function validateMail(email) {
	
	//hae tietokannasta onko ko. email olemassa ja ilmoita, jos on, muutoin tee k�ytt�j�

    $.ajax(
        {
            url: "http://localhost:3002/Auth?auth=" + email,
            method: 'GET', // Vaihtoehtoina get, post, delete, put (ainakin)
            "dataType": "json"



        }).done(function (data, textStatus, jqXHR) {
            // Suoritetaan kun kutsu on valmis
            console.log("OK", data);
            // info = JSON.parse(data);


            if (typeof data[0] !== 'undefined') {

                var kayttaja = data[0]['kayttajanimi'];

                if (kayttaja !== email) {
                    console.log("kayttaja OK!");
                    createUser();

                }
                else {
                    console.log("kayttaja ei OK");
                    return false;
                }
            }
            else {
                console.log("data undefined, ok to go createUser kutsutaan");
                createUser();
                return true;
            }

        }).fail(function (jqXHR, textStatus, errorThrown) {
            // Suoriteaan, jos kutsu ep�onnistuu
            console.log("Kutsu ep�onnistui");

        }).always(function (jqXHR, textStatus, errorThrown) {
            // suoritetaan aina (riippumatta onnistuiko kutsu vai ei)
            // HUOM! 1. parametri sis�lt�� datan jos kutsu onnistui ja 3. parametri jqXHR-olion. Jos kutsu ep�onnistui, 1. parametri on jqXHR-olio ja 3. errorThrown
            console.log("Kutsu always");

        });


}

function createUser() {

    var etunimi = $('#etunimi').val();
    var sukunimi = $('#sukunimi').val();
    var tunnus = $('#tunnus').val();
    var salasana = $('#salasana').val();
   

    $.ajax(
        {
            url: "http://localhost:3002/register",
            method: 'POST',  // Vaihtoehtoina get, post, delete, put (ainakin)         
            data: {fname: etunimi, lname: sukunimi, email: tunnus, password: salasana} // json-muodossa data, joka halutaan l�hett�� serverille (sama kuin laittaisi url:n per��n ?delay=1) 
        }).done(function (data, textStatus, jqXHR) {
            // Suoritetaan kun kutsu on valmis
            console.log("create user ok");
            alert("K�ytt�j� luotu! Ole hyv� ja kirjaudu sis��n k�ytt��ksesi palveluitamme.");
            window.location = "http://localhost:3002/Login";
        }).fail(function (jqXHR, textStatus, errorThrown) {
            // Suoriteaan, jos kutsu ep�onnistuu
            console.log("createUser-Kutsu ep�onnistui");

        }).always(function (jqXHR, textStatus, errorThrown) {
            // suoritetaan aina (riippumatta onnistuiko kutsu vai ei)
            // HUOM! 1. parametri sis�lt�� datan jos kutsu onnistui ja 3. parametri jqXHR-olion. Jos kutsu ep�onnistui, 1. parametri on jqXHR-olio ja 3. errorThrown
            console.log("Kutsu always");
            
        });

}